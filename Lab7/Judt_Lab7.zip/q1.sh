# Jordan Judt
# CSC 492
# 
# Lab 7, Question 1
# 3-16-2018

#!/bin/bash
num=`who | wc -l`
echo "There are $num user(s) logged into the system."

