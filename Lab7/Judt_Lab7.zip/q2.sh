# Jordan Judt
# CSC 492
# 
# Lab 7, Question 2
# 3-16-2018

#!/bin/bash
num=`ls | wc -l`
echo "There are $num files in your current directory."

