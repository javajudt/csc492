# Jordan Judt
# CSC 492
# 
# Lab 7, Question 5
# 3-16-2018

#!/bin/bash
text="hi 1 2 3 4 5"
text=$(echo $text | tr -d ' ')
echo "text=$text"

